## 🍑 Bug Report / گزارش باگ

**Butt color at time of issue / رنگ باسن در زمان مشکل:**
[ ] ⬜ White / سفید
[ ] 🩶 Gray / خاکستری  
[ ] 🟤 Brown / قهوه‌ای
[ ] ⬛ Dark / تیره
[ ] 🔴 Red (how?? / چطور؟؟)

**Describe the bug / توضیح باگ:**
...

**Expected behavior / رفتار مورد انتظار:**
Tunnel working perfectly because my butt is white
تانل کار کنه چون باسنم سفیده

**Actual behavior / رفتار واقعی:**
...

**Have you tried making your butt whiter? / آیا سعی کردی باسنتو سفیدتر کنی؟**
[ ] Yes / بله
[ ] No / خیر
[ ] I refuse / امتناع می‌کنم
